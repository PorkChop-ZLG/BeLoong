Copyright (c) 2021-2025 kohara & szarkan

PERMITTED USES
===================

- You are free to use Stellarity for whatever personal purpose you desire.

- You are free to modify the pack to your suiting.

- You are permitted to use Stellarity as a part of for-profit projects - servers, modpacks, etc.
    - Just remember about kohara and Szarkan during crediting.

PROHIBITED USES
===================

- You are forbidden to reupload, republish or redistribute Stellarity lite, modified or not.
    - You are allowed to publish modified versions of Stellarity lite only under kohara's permission. However, you are forbidden to claim it as your own creation and must leave appropriate credit.
        - This also applies to using modified versions of Stellarity in modpacks.
